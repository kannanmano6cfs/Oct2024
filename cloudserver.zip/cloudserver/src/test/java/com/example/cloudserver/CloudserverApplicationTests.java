package com.example.cloudserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
