package com.order.ms.controller;

import ch.qos.logback.core.net.SyslogOutputStream;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.order.ms.dto.CustomerOrder;
import com.order.ms.dto.OrderStatus;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/api")
public class OrderController {

	private RestTemplate restTemplate;

	private static final String STOCK_API = "http://localhost:8082/api/updateStock";

	private static final String STOCK_API1 = "http://localhost:8082/api/getStockMsg";

	public OrderController(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@PostMapping("/orders")
    //@CircuitBreaker(name="mycircuitbreaker", fallbackMethod = "fallback")
	public OrderStatus doOrder(@RequestBody CustomerOrder customerOrder) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<CustomerOrder> request = new HttpEntity<>(customerOrder, headers);

		ResponseEntity<OrderStatus> responseEntity = restTemplate.postForEntity(STOCK_API, request, OrderStatus.class);
		OrderStatus orderStatus = responseEntity.getBody();

		System.out.println("Order Status::" + orderStatus);

		return orderStatus;
	}
	int attempt=0;

	@GetMapping("/getstock")
	@Retry(name="myretry", fallbackMethod = "fallback")
	public ResponseEntity<String> getStock() {
		System.out.println("Order Request to stock "+attempt++);
		ResponseEntity<String> responseEntity = restTemplate.getForEntity(STOCK_API1, String.class);
		System.out.println("Service Connected");
		return responseEntity;
	}

	public ResponseEntity<String> fallback(Exception e) {
		attempt=0;
		System.out.println("Service Retried");
		return new ResponseEntity<>("Called fallback method", HttpStatus.SERVICE_UNAVAILABLE);
	}
}
