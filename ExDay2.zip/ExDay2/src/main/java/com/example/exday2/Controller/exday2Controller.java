package com.example.exday2.Controller;

import com.example.exday2.Model.Student;
import com.example.exday2.Repository.exday2Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class exday2Controller {

    @Autowired
    private exday2Repository repo;

    @PostMapping("/savedetails")
    public ResponseEntity<String> savedetails(@RequestBody Student student){
        repo.save(student);
        return new ResponseEntity<>("Student details added successfully", HttpStatus.OK);
    }

    @GetMapping("/getcount")
    public ResponseEntity<String> getcount(){
        long count = repo.count();
        return new ResponseEntity<>("Count of students is " + count, HttpStatus.OK);
    }

    @GetMapping("/getdetails")
    public Iterable<Student> getdetails(){
        Iterable<Student> student=repo.findAll();
        return student;
    }

    @GetMapping("/getbyId/{id}")
    public Student getbyId1(@PathVariable int id){
        Optional<Student> student=repo.findById(id);
        return student.orElseThrow();
    }

    @GetMapping("/getbyName")
    public Iterable<Student> getbyname(@RequestParam String name){
       Iterable<Student> student= repo.findByName(name);
       return student;
    }

    @PutMapping("/updatedetails")
    public ResponseEntity<String> updatedetails(@RequestBody Student student,@RequestParam int id){
        Student st=repo.findById(id).orElseThrow();
        st.setName(student.getName());
        st.setAge(student.getAge());
        st.setGender(student.getGender());
        repo.save(st);
        return new ResponseEntity<>("Student details updated successfully", HttpStatus.OK);
    }

    @DeleteMapping("/deletedetails")
    public ResponseEntity<String> deletedetails(@RequestParam int id){
        repo.deleteById(id);
        return new ResponseEntity<>("Student details deleted successfully", HttpStatus.OK);
    }
}
