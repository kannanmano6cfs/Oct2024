package com.example.exday2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExDay2Application {

	public static void main(String[] args) {
		SpringApplication.run(ExDay2Application.class, args);
	}

}
