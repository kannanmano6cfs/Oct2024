package com.example.exday2.Repository;

import com.example.exday2.Model.Student;
import org.springframework.data.repository.CrudRepository;

public interface exday2Repository extends CrudRepository<Student,Integer> {

    Iterable<Student> findByName(String name);
}
