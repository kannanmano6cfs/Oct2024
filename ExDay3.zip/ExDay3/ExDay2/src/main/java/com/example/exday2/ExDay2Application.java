package com.example.exday2;

import com.example.exday2.config.websecurityconfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
@EnableWebSecurity
@Import(websecurityconfig.class)
public class ExDay2Application {

	public static void main(String[] args) {
		SpringApplication.run(ExDay2Application.class, args);
	}

}
