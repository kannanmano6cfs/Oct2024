package com.example.ExSBApp1.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ExController {

    //Day1
//    @Value("${msg}")
//    String message;
//    @Autowired
//    private Environment env;
//
//    @GetMapping("/details")
//    public String getDetails()
//    {
//        return env.getProperty("msg");
//    }


}
